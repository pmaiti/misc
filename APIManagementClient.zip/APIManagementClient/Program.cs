﻿using System;
using System.Net.Http.Headers;
using System.Text;
using System.Net.Http;
using System.Web;
using System.IO;

namespace CSHttpClientSample
{
    static class Program
    {
        static void Main()
        {
            MakeRequest();
            Console.WriteLine("Hit ENTER to exit...");
            Console.ReadLine();
        }

        static async void MakeRequest()
        {
            var client = new HttpClient();


            // Request headers

            client.DefaultRequestHeaders.CacheControl = CacheControlHeaderValue.Parse("no-cache");

            //client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "d5e9184fcd504a039c4e46e0e020ce49"); //Starter
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "5eb35595720944879155ce2c89d3a12d"); //Unlimited
            var uri = "https://apim-eus-d-7308-bofa.azure-api.net/conference/topics?dayno=1";

            var response = await client.GetAsync(uri);

            Console.WriteLine(response.Content.ReadAsStringAsync().Result);

        }
    }
}
